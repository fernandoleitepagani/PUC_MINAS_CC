#include <stdio.h>

/*
 * Calcula o MDC(a, b) usando o Algoritmo de Euclides recursivo.
 * Pre-condicao: a >= b >= 0.
 */
int mdc(int a, int b) {
    if (b == 0) {
        // Caso base: MDC(a, 0) = a
        return a;
    }
    return mdc(b, a % b);
}

int main(void) {
    int a, b;

    printf("Digite dois inteiros a e b, com a >= b >= 0: ");
    if (scanf("%d %d", &a, &b) != 2 || a < b || b < 0) {
        printf("Entrada invalida. Lembre-se: a >= b >= 0.\n");
        return 1;
    }

    printf("MDC(%d, %d) = %d\n", a, b, mdc(a, b));

    return 0;
}
